function [matPredict]=label1(md_adjmat,YW,D_CS,d_SS,alpha,beta,w,DN,dN)
B=YW';
similairty_matrix=Label_Propagation(B,0,dN,'regulation2');    
LP_disease_result=calculate_labels(similairty_matrix,md_adjmat',alpha); 
B=YW;
similairty_matrix=Label_Propagation(B,0,DN,'regulation2');    
 LP_Drug_result=calculate_labels(similairty_matrix,md_adjmat,beta);

matPredict=w*LP_Drug_result+(1-w)*(LP_disease_result');
end

