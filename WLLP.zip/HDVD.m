clc;clear;
warning('off');
tic
addpath('HDVD')
load('drugsim.mat');
%%
d_SS= virussim;
A = virusdrug;%
D_CS=drugsim;
%%
A_ori=A;%219*34
  y_train=WKNKN(A,D_CS,d_SS,4,1); %219*34
   F_1_ori=label1(A,y_train,D_CS,d_SS,0.4,0.5,0.4,100,34);

F_1_ori_ori=F_1_ori;
index=find(A_ori==1);
auc = zeros(1,10);
aupr = zeros(1,10);
for i = 1:10
    i
    indices = crossvalind('Kfold', length(index), 10);
    A = A_ori;
    F_1_ori=F_1_ori_ori;  
    for cv = 1:10
        cv;
        index_2 = find(cv == indices);      
        A(index(index_2)) = 0;        
          y_train_1=WKNKN(A,D_CS,d_SS,4,1); %219*34
         F_1=label1(A,y_train_1,D_CS,d_SS,0.4,0.5,0.4,100,34); 
        F_1_ori(index(index_2)) = F_1(index(index_2));        
        A = A_ori;
    end
    F_1_ori(isnan(F_1_ori))=0;
    pre_label_score = F_1_ori(:);
    label_y = A_ori(:);
    auc(i) = roc_1(pre_label_score,label_y,'red');
     aupr(i)=pr_cure(pre_label_score,label_y,'blue');
     auc(i)
      aupr(i)
end
auc_ave = mean(auc);
auc_std = std(auc);
aupr_ave = mean(aupr);
aupr_std = std(aupr);
toc