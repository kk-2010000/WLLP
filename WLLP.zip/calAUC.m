function AUC=calAUC(inputG,outputG)
A=find(inputG(:,:)==1);
B=find(inputG(:,:)==0);
[n,~]=size(A); 
[m,~]=size(B); 
out=0;
for i=1:n
    i;
    for j=1:m
        if(outputG(A(i))>outputG(B(j)))
            out=out+1;
        end
        if(outputG(A(i))==outputG(B(j)))
            out=out+0.5;
        end
    end
end

AUC=out/(m*n);

end

